﻿using Microsoft.AspNetCore.Mvc;

namespace ASP_A3._6.Controllers
{
    public class InfoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
