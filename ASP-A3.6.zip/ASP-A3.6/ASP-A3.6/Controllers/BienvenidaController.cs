﻿
using Microsoft.AspNetCore.Mvc;

namespace ASP_A3._6.Controllers
{

   
        public class BienvenidaController : Controller
        {
            public IActionResult Index()
            {
                ViewBag.Nombre = "Arroyo";
                ViewBag.Fecha = DateTime.Now;

                return View();
            }
        }
    }
