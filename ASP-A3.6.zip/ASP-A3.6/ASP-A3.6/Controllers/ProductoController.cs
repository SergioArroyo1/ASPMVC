﻿using Microsoft.AspNetCore.Mvc;

namespace ASP_A3._6.Controllers
{
    public class ProductosController : Controller
    {
        public IActionResult Index()
        {
            var productos = new List<dynamic>
            {
                new { Nombre = "Monitor", Precio = 120 },
                new { Nombre = "Teclado", Precio = 25 },
                new { Nombre = "Ratón", Precio = 15 },
                new { Nombre = "Impresora", Precio = 80 },
                new { Nombre = "USB 32GB", Precio = 12 }
            };

            ViewBag.Productos = productos;

            return View();
        }
    }
}
